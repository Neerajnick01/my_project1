package restuarent;
//import java.util.Vector;
import java.util.Vector;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import databaseconnection.*;




public class  Manager
{
		
	public static Vector getData(String email) throws Exception
	{
		Connection con = databasecon.getconnection();
		Statement st=con.createStatement();

		ResultSet rs=st.executeQuery("desc Items");
		int c=0;
		while(rs.next()){
		c++;
		}
		Vector v=new Vector();
 rs=st.executeQuery("select * from Items where memail='"+email+"' ");
		if(rs.next()){
		for (int i=1;i<=c ;i++)
		{
		v.add(rs.getString(i));
		}

									
		}
			return v;
		}
//		System.out.println(out);
	

	public static void main(String[] args)  throws Exception
	{
		Vector vv=Manager.getData("ali@gmail.com");
		System.out.println("Hello W"+vv.size());
	}



}
