package Algorithm;
//import java.util.Vector;
import java.lang.Math;
import java.util.Map;
import java.util.HashMap;
 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.io.*;

import databaseconnection.*;




public class  ir2
{
		
	public static String m() throws Exception
	{
		Connection con = databasecon.getconnection();
		Statement st=con.createStatement();

		Statement st2=con.createStatement();

		String[] arr=null;		String s="";
		st2.executeUpdate("delete from temp");
		ResultSet rs=st.executeQuery("select rkeys from Items");
		while(rs.next()){

		s=rs.getString(1);
		arr=s.split(",");

		int ii=0;
		for(int i=0;i<arr.length;i++ )
		{
			try{
			st2.executeUpdate("insert into temp values('"+arr[i].trim()+"')");
			}
			catch(Exception e){}
								
		}
		
		}
//		System.out.println(out);
		return "com";
	}


//  @SuppressWarnings("boxing")
  public static int gethash(String s) {
 
     int d= 0;
   d= s.hashCode(); 
    return d;
  }



	public static void m2() throws Exception
	{
		Connection con = databasecon.getconnection();
		Statement st=con.createStatement();

		Statement st2=con.createStatement();
		st2.executeUpdate("delete from hashed");
		ResultSet rs=st.executeQuery("select * from temp");
		while(rs.next())
		{
			st2.executeUpdate("insert into hashed values('"+rs.getString(1)+"',"+gethash(rs.getString(1))+")");
				//System.out.println(gethash(rs.getString(1)));
		}
	}



	public static void main(String[] args) throws Exception
	{
			ir2.m();
						ir2.m2();
	}
}
