package Algorithm;
//import java.util.Vector;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import databaseconnection.*;




public class  SIIndex
{
		
	public static void m(String city) throws Exception
	{
		String tab="si_"+city;

		Connection con = databasecon.getconnection();
		Statement st=con.createStatement();
		Statement st1=con.createStatement();
		Statement st2=con.createStatement();
		try{st2.executeUpdate("delete from "+tab);}catch(Exception e){}
		try{st2.executeUpdate("CREATE TABLE "+tab+" (  word varchar(500) default NULL,  hashid double default NULL,  ilist varchar(800) default NULL)  ");}catch(Exception e){}
		String[] arr=null;		String s="";String s2=""; String sql="";String s3="";
	
		ResultSet rs=st.executeQuery("select * from hashed");
		ResultSet rs2=null;
			int c=0;
		while(rs.next()){
				s3="";
				s=rs.getString(1);				s2=rs.getString(2);

			sql="SELECT rid FROM Items WHERE rkeys LIKE '%"+s+"%'&& city LIKE '%"+city+"%'";
			System.out.println(sql);
			rs2=st1.executeQuery(sql);

			while(rs2.next())
			{

					s3=s3+" "+rs2.getString(1);
			}

		
			st2.executeUpdate("insert into "+tab+" values('"+s+"','"+s2+"','"+s3.trim()+"')");


			}
		}
		



public static void main(String[] args) throws Exception
	{
			SIIndex.m("Hyderabad");
	}
}
