package Geo;

import java.io.PrintStream;

public class DistCalc
{
  public static double distance(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    double d1 = Double.parseDouble(paramString1);
    double d2 = Double.parseDouble(paramString2);
    double d3 = Double.parseDouble(paramString3);
    double d4 = Double.parseDouble(paramString4);
    double d5 = d2 - d4;
    double d6 = Math.sin(deg2rad(d1)) * Math.sin(deg2rad(d3)) + Math.cos(deg2rad(d1)) * Math.cos(deg2rad(d3)) * Math.cos(deg2rad(d5));
    d6 = Math.acos(d6);
    d6 = rad2deg(d6);
    d6 = d6 * 60.0D * 1.1515D;
    if (paramString5 == "K")
    {
      d6 *= 1.609344D;
      
      d6 = Math.round(d6);
      if (d6 > 1.0D) {
        d6 += 2.0D;
      }
    }
    else if (paramString5 == "N")
    {
      d6 *= 0.8684D;
    }
    return d6;
  }
  
  public static double deg2rad(double paramDouble)
  {
    return paramDouble * 3.141592653589793D / 180.0D;
  }
  
  public static double rad2deg(double paramDouble)
  {
    return paramDouble * 180.0D / 3.141592653589793D;
  }
  
  public static void main(String[] paramArrayOfString)
  {
    System.out.println(distance("17.4677964", "78.42527919999998", "17.4374614", "78.4482878", "K") + " Kilometers");
    System.out.println(distance("17.4677964", "78.42527919999998", "17.4374614", "78.4482878", "N") + " Nautical Miles");
  }
}
