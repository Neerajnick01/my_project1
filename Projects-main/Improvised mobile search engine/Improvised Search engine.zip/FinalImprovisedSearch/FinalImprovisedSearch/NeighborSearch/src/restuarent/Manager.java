package restuarent;

import databaseconnection.databasecon;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class Manager
{
  public static Vector getData(String paramString)
    throws Exception
  {
    Connection localConnection = databasecon.getconnection();
    Statement localStatement = localConnection.createStatement();
    
    ResultSet localResultSet = localStatement.executeQuery("desc Items");
    int i = 0;
    while (localResultSet.next()) {
      i++;
    }
    Vector localVector = new Vector();
    localResultSet = localStatement.executeQuery("select * from Items where memail='" + paramString + "' ");
    if (localResultSet.next()) {
      for (int j = 1; j <= i; j++) {
        localVector.add(localResultSet.getString(j));
      }
    }
    return localVector;
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    Vector localVector = getData("ali@gmail.com");
    System.out.println("Hello W" + localVector.size());
  }
}
